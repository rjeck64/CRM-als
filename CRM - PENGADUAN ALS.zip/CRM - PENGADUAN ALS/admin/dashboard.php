<h2>Selamat datang, <?php echo $_SESSION['username']; ?>!</h2>
<p>Ini adalah halaman admin.</p>